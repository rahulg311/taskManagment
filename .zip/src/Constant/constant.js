
//  localhost all url 
export const baseUrl = "https://api1.parinaam.in/api/JuryLogin/";
// export const uploadFileBaeUrl ="http://localhost:3001/uploadFile";
// // nodejs file acreesurl
// export const ViewAllFileKyc ="http://localhost:3001/uploads/RetailerKyc/";


//  fileUplode sort name
//  GST file = GST
//  PanCard file = PC
//  Shop file = SP
//  Bank file = BA