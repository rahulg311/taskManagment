//  retaler api method
export const MethodNames = {
    CheckUserExists :"CheckUserExists",
    getjuryusercategorylist:"getjuryusercategorylist",
    ListOfEntries:"ListOfEntries",
    savescore:"savescore",
    savescoreremarks:"savescoreremarks",
    scorelistfinalsubmit:"scorelistfinalsubmit",
    getjourylist:"getjourylist",
    juryscorelist:"juryscorelist"
    
}